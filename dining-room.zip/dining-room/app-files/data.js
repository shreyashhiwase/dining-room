var APP_DATA = {
  "scenes": [
    {
      "id": "0-dining-room-of-vishwakarma",
      "name": "Dining Room of Vishwakarma",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 0.2108088202642726,
        "pitch": 0.0025346686986544853,
        "fov": 1.5537519122748535
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "Dining Room",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
